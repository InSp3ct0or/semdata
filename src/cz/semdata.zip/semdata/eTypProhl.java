package cz.semdata;

public enum eTypProhl {
    SIRKA,  // Breadth-first (BFS)
    HLOUBKA // Depth-first (In-order DFS)
}