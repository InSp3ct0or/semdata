package cz.semdata;

public class OblastPlnaException extends RuntimeException {
    public OblastPlnaException(String message) {
        super(message);
    }
}
