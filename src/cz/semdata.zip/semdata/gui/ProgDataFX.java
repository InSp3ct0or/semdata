package cz.semdata.gui;

import cz.semdata.*;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.Iterator;
import java.util.Random;

public class ProgDataFX extends Application {

    private final SpravaOblasti sprava = new SpravaOblasti();
    private TextArea logArea;
    private TextField tfId, tfName, tfKap, tfParam;
    private Random rand = new Random();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Semestrální práce - Správa dat (JavaFX)");

        // --- Layout ---
        BorderPane root = new BorderPane();

        // --- Levý panel (Ovládání) ---
        VBox leftPanel = new VBox(10);
        leftPanel.setPadding(new Insets(10));
        leftPanel.setPrefWidth(250);
        leftPanel.setStyle("-fx-background-color: #f0f0f0;");

        // Init sekce
        Label lblInit = new Label("Inicializace:");
        tfKap = new TextField("5");
        tfKap.setPromptText("Max kapacita");
        Button btnInit = new Button("Init");
        btnInit.setOnAction(e -> actionInit());

        // Vložení sekce
        Label lblInsert = new Label("Vložení Záznamu:");
        tfId = new TextField(); tfId.setPromptText("ID");
        tfName = new TextField(); tfName.setPromptText("Jméno (Klíč)");
        Button btnAdd = new Button("Vložit");
        btnAdd.setOnAction(e -> actionAdd());
        Button btnGen = new Button("Generovat N");
        btnGen.setOnAction(e -> actionGen());

        // Tabulka operace
        Label lblTable = new Label("Operace Tabulky (BVS):");
        tfParam = new TextField(); tfParam.setPromptText("Parametr (Klíč/k)");
        Button btnFind = new Button("Najdi (Klíč)");
        btnFind.setOnAction(e -> actionFind());
        Button btnRemove = new Button("Odeber (Klíč)");
        btnRemove.setOnAction(e -> actionRemoveKey());
        Button btnSelect = new Button("Select (k)");
        btnSelect.setOnAction(e -> actionSelect());
        Button btnRank = new Button("Rank (Klíč)");
        btnRank.setOnAction(e -> actionRank());

        // Zobrazení
        Label lblShow = new Label("Výpisy:");
        ComboBox<String> cbIter = new ComboBox<>();
        cbIter.getItems().addAll("Oblastí (Listy)", "Strom (In-Order)", "Strom (BFS)");
        cbIter.getSelectionModel().selectFirst();
        Button btnShow = new Button("Zobrazit");
        btnShow.setOnAction(e -> actionShow(cbIter.getValue()));

        // Soubory
        Button btnLoad = new Button("Načíst ze souboru");
        btnLoad.setOnAction(e -> actionLoad(primaryStage));
        Button btnSave = new Button("Uložit do souboru");
        btnSave.setOnAction(e -> actionSave(primaryStage));

        Button btnClear = new Button("Zrušit vše");
        btnClear.setOnAction(e -> { sprava.zrus(); log("Vše zrušeno."); });

        leftPanel.getChildren().addAll(
                lblInit, tfKap, btnInit, new Separator(),
                lblInsert, tfId, tfName, new HBox(5, btnAdd, btnGen), new Separator(),
                lblTable, tfParam, new HBox(5, btnFind, btnRemove), new HBox(5, btnSelect, btnRank), new Separator(),
                lblShow, cbIter, btnShow, new Separator(),
                btnLoad, btnSave, btnClear
        );

        // --- Střed (Log) ---
        logArea = new TextArea();
        logArea.setEditable(false);
        logArea.setFont(javafx.scene.text.Font.font("Monospaced", 12));

        root.setLeft(leftPanel);
        root.setCenter(logArea);

        Scene scene = new Scene(root, 900, 600);
        primaryStage.setScene(scene);
        primaryStage.show();

        log("Aplikace spuštěna. Proveďte Init.");
    }

    // --- Actions ---

    private void actionInit() {
        try {
            int k = Integer.parseInt(tfKap.getText());
            sprava.init(k);
            log("Inicializováno. Kapacita oblasti: " + k);
        } catch (NumberFormatException e) {
            alert("Chyba", "Kapacita musí být číslo.");
        } catch (Exception e) {
            alert("Chyba", e.getMessage());
        }
    }

    private void actionAdd() {
        try {
            int id = Integer.parseInt(tfId.getText());
            String name = tfName.getText();
            if (name.isEmpty()) throw new IllegalArgumentException("Jméno nesmí být prázdné");
            sprava.vlozZaznam(new Zaznam(id, name));
            log("Vloženo: " + id + ", " + name);
            tfId.clear(); tfName.clear();
        } catch (Exception e) {
            log("Chyba vložení: " + e.getMessage());
        }
    }

    private void actionGen() {
        try {
            int n = Integer.parseInt(tfParam.getText());
            int startId = 1000 + rand.nextInt(1000);
            for (int i = 0; i < n; i++) {
                int id = startId + i;
                String name = "z_" + id + "_" + (char)('A' + rand.nextInt(26));
                sprava.vlozZaznam(new Zaznam(id, name));
            }
            log("Vygenerováno " + n + " záznamů.");
        } catch (Exception e) {
            log("Pro generování zadejte počet do pole 'Parametr'.");
        }
    }

    private void actionFind() {
        String key = tfParam.getText();
        Zaznam z = sprava.getTabulka().najdi(key);
        if (z != null) log("Nalezeno: " + z);
        else log("Nenalezeno: " + key);
    }

    private void actionRemoveKey() {
        // Odebrání dle klíče z Tabulky vyžaduje, abychom věděli, jak to promítnout do seznamů.
        // Zadání C říká: "odeberZaznam(Zaznam)".
        // Takže nejdřív najdeme, pak odebereme komplexně.
        String key = tfParam.getText();
        Zaznam z = sprava.getTabulka().najdi(key);
        if (z != null) {
            sprava.odeberZaznam(z);
            log("Odebráno (BVS i Listy): " + z);
        } else {
            log("Záznam pro odebrání nenalezen: " + key);
        }
    }

    private void actionSelect() {
        try {
            int k = Integer.parseInt(tfParam.getText());
            Zaznam z = sprava.getTabulka().select(k);
            log("Select(" + k + "): " + (z != null ? z : "null"));
        } catch (NumberFormatException e) {
            log("Parametr musí být číslo.");
        }
    }

    private void actionRank() {
        String key = tfParam.getText();
        int r = sprava.getTabulka().rank(key);
        log("Rank(" + key + "): " + r);
    }

    private void actionShow(String mode) {
        logArea.clear();
        StringBuilder sb = new StringBuilder();

        if (mode.startsWith("Oblastí")) {
            sb.append(sprava.dumpState());
        } else if (mode.contains("Strom")) {
            eTypProhl typ = mode.contains("BFS") ? eTypProhl.SIRKA : eTypProhl.HLOUBKA;
            sb.append("=== Výpis Stromu (" + typ + ") ===").append("\n");
            Iterator<Zaznam> it = sprava.getTabulka().vytvorIterator(typ);
            while (it.hasNext()) {
                sb.append(it.next()).append("\n");
            }
        }
        logArea.setText(sb.toString());
    }

    private void actionLoad(Stage stage) {
        FileChooser fc = new FileChooser();
        File f = fc.showOpenDialog(stage);
        if (f != null) {
            try {
                sprava.automat(f.getAbsolutePath());
                log("Načteno ze souboru: " + f.getName());
            } catch (Exception e) {
                log("Chyba načítání: " + e.getMessage());
            }
        }
    }

    private void actionSave(Stage stage) {
        FileChooser fc = new FileChooser();
        File f = fc.showSaveDialog(stage);
        if (f != null) {
            try {
                sprava.ulozDoSouboru(f.getAbsolutePath());
                log("Uloženo do: " + f.getName());
            } catch (Exception e) {
                log("Chyba ukládání: " + e.getMessage());
            }
        }
    }

    private void log(String msg) {
        logArea.appendText(msg + "\n");
    }

    private void alert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}