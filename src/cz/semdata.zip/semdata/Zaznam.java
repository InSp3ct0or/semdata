package cz.semdata;

import java.util.Objects;

public class Zaznam {
    private final int id;
    private final String jmeno;

    public Zaznam(int id, String jmeno) {
        this.id = id;
        this.jmeno = jmeno;
    }

    public int getId() {
        return id;
    }

    public String getJmeno() {
        return jmeno;
    }

    @Override
    public String toString() {
        return "Zaznam{" + id + ", '" + jmeno + "'}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Zaznam)) return false;
        Zaznam zaznam = (Zaznam) o;
        return id == zaznam.id && Objects.equals(jmeno, zaznam.jmeno);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, jmeno);
    }
}
