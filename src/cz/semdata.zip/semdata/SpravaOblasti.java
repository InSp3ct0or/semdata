package cz.semdata;

import java.io.*;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.concurrent.atomic.AtomicInteger;

public class SpravaOblasti implements Iterable<Oblast> {
    private final IAbstrDoubleList<Oblast> oblasti;
    private int maxKapacitaOblasti;
    private final AtomicInteger idGeneratorOblasti = new AtomicInteger(1);

    // NOVÉ: Centrální vyhledávací tabulka
    private final TabZaznamu tabulkaZaznamu;

    public SpravaOblasti() {
        oblasti = new AbstrDoubleList<>();
        tabulkaZaznamu = new TabZaznamu();
    }

    // Getter pro UI, aby mohlo volat operace tabulky
    public TabZaznamu getTabulka() {
        return tabulkaZaznamu;
    }

    public void init(int maxKapacita) {
        if (maxKapacita <= 0) throw new IllegalArgumentException("maxKapacita musi byt > 0");
        this.maxKapacitaOblasti = maxKapacita;
        zrus(); // vyčistí vše
        Oblast prvni = new Oblast(idGeneratorOblasti.getAndIncrement(), maxKapacitaOblasti);
        oblasti.vlozPrvni(prvni);
    }

    public void vlozZaznam(Zaznam zaznam) {
        // 1. Vložení do stromu
        tabulkaZaznamu.vloz(zaznam);

        // 2. Vložení do oblastí (First-Fit)
        for (Oblast o : oblasti) {
            if (!o.jePlna()) {
                o.vlozZaznam(zaznam);
                return;
            }
        }
        Oblast nova = new Oblast(idGeneratorOblasti.getAndIncrement(), maxKapacitaOblasti);
        nova.vlozZaznam(zaznam);
        oblasti.vlozPosledni(nova);
    }

    public void vlozZaznamPozice(Zaznam zaznam, EnumPozice pozice) {
        // Poznámka: Vložení na pozici v listu je specifické pro ADL.
        // V tabulce pozice nehraje roli, jen klíč.
        tabulkaZaznamu.vloz(zaznam);

        Oblast aktu;
        try {
            aktu = oblasti.zpristupniAktualni();
        } catch (Exception e) {
            aktu = oblasti.zpristupniPrvni();
        }
        if (aktu.jePlna()) {
            throw new OblastPlnaException("Aktuální oblast (ID=" + aktu.getId() + ") je plná.");
        }
        aktu.vlozZaznam(zaznam, pozice);
    }

    // NOVÉ: Požadavek C - odebrání z tabulky i seznamu
    public void odeberZaznam(Zaznam zaznam) {
        if (zaznam == null) return;

        // 1. Odebrání z Tabulky
        tabulkaZaznamu.odeber(zaznam.getJmeno());

        // 2. Odebrání z Oblastí (musíme projít oblasti, protože nevíme, kde je)
        for (Oblast o : oblasti) {
            if (o.odeberKonkrektni(zaznam)) {
                // Pokud se podařilo odebrat, zkontrolujeme, zda oblast nezůstala prázdná (volitelné, dle logiky)
                return; // Záznam je unikátní (předpoklad), můžeme skončit
            }
        }
    }

    // Původní metody...
    public Oblast zpristupniOblast(EnumPozice pozice) {
        return switch (pozice) {
            case PRVNI -> oblasti.zpristupniPrvni();
            case POSLEDNI -> oblasti.zpristupniPosledni();
            case NASLEDNIK -> oblasti.zpristupniNaslednika();
            case PREDCHUDCE -> oblasti.zpristupniPredchudce();
            case AKTUALNI -> oblasti.zpristupniAktualni();
        };
    }

    public Oblast odeberOblast(EnumPozice pozice) {
        Oblast o;
        try {
            o = switch (pozice) {
                case PRVNI -> oblasti.odeberPrvni();
                case POSLEDNI -> oblasti.odeberPosledni();
                case NASLEDNIK -> oblasti.odeberNaslednika();
                case PREDCHUDCE -> oblasti.odeberPredchudce();
                case AKTUALNI -> oblasti.odeberAktualni();
            };
        } catch (NoSuchElementException e) {
            throw new NoSuchElementException("Nelze odebrat oblast: " + e.getMessage());
        }
        // Při odebrání oblasti musíme odebrat i záznamy z tabulky!
        for (Zaznam z : o) {
            tabulkaZaznamu.odeber(z.getJmeno());
        }
        return o;
    }

    public void zrus() {
        for (Oblast o : oblasti) {
            o.zrus();
        }
        oblasti.zrus();
        tabulkaZaznamu.zrus();
    }

    @Override
    public Iterator<Oblast> iterator() {
        return oblasti.iterator();
    }

    public void automat(String soubor) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(soubor))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(";", 2);
                int id = Integer.parseInt(parts[0].trim());
                String jmeno = (parts.length > 1) ? parts[1].trim() : "zaznam" + id;

                vlozZaznam(new Zaznam(id, jmeno));
            }
        }
    }

    public void ulozDoSouboru(String soubor) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(soubor))) {
            bw.write(dumpState());
        }
    }

    public String dumpState() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Oblasti ===").append(System.lineSeparator());
        for (Oblast o : this) {
            sb.append(o).append(System.lineSeparator());
            for (Zaznam z : o) {
                sb.append("   ").append(z).append(System.lineSeparator());
            }
        }
        return sb.toString();
    }
}