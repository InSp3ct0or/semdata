package cz.semdata;


public enum EnumPozice {
    PRVNI,
    POSLEDNI,
    NASLEDNIK,
    PREDCHUDCE,
    AKTUALNI
}
